/**
 * Functions for calc necessary quantity
 * 
 * @since 1.0.0
 */
jQuery(function($) {
    $('select[name="wallpaper-calculator-height-select"]').change(function() {
        calculateNecessaryQtd();
    });

    $('#get-width-wallpaper').on('input', function() {
        calculateNecessaryQtd();
    });

    function calculateNecessaryQtd() {
        let getHeightUser = parseFloat($('select[name="wallpaper-calculator-height-select"]').val());
        let getWidthUser = parseFloat($('#get-width-wallpaper').val());

        if (!isNaN(getHeightUser) && !isNaN(getWidthUser)) {
            let wallArea = getHeightUser * getWidthUser;
            $('#size-wallpaper-result').val(wallArea.toFixed(2));

            let lengthWallpaperProduct = parseFloat($('#lenght-wallpaper-product').val());
            let widthWallpaperProduct = parseFloat($('#width-wallpaper-product').val());
            let wallpaperArea = lengthWallpaperProduct * widthWallpaperProduct;
            let necessaryQtd = Math.ceil(wallArea / wallpaperArea);

            $('.result-quantity').text('Você precisa de ' + necessaryQtd + ' folhas');
            $('form.cart input[name="quantity"]').val(necessaryQtd);
            $('form.cart button[name="add-to-cart"]').addClass('pulse-add-to-cart-button');

            $('.wallpaper-calculator-result').fadeOut(300, function() {
                $(this).addClass('active').fadeIn(300);
            });
        } else {
            $('form.cart button[name="add-to-cart"]').removeClass('pulse-add-to-cart-button');
            $('.wallpaper-calculator-result').removeClass('active');
        }
    }
});