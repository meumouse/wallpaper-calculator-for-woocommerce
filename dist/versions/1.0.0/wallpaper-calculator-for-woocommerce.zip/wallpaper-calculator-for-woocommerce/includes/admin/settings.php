<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; } ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">

<h1 class="wallpaper-calculator-for-woocommerce-admin-section-tile"><?php echo get_admin_page_title() ?></h1>

<div class="toast updated-option-success">
    <div class="toast-header bg-success text-white">
        <i class="fa-regular fa-circle-check me-3"></i>
        <span class="me-auto"><?php _e( 'Salvo com sucesso', 'wallpaper-calculator-for-woocommerce' ); ?></span>
    </div>
    <div class="toast-body"><?php _e( 'As configurações foram atualizadas!', 'wallpaper-calculator-for-woocommerce' ); ?></div>
</div>

<?php settings_errors(); ?>

<div class="wallpaper-calculator-for-woocommerce-wrapper">
    <div class="nav-tab-wrapper wallpaper-calculator-for-woocommerce-tab-wrapper">
        <a href="#general-settings" class="nav-tab nav-tab-active"><?php echo esc_html__( 'Geral', 'wallpaper-calculator-for-woocommerce' ) ?></a>
        <a href="#design-settings" class="nav-tab "><?php echo esc_html__( 'Estilos', 'wallpaper-calculator-for-woocommerce' ) ?></a>
    </div>

    <form method="post" action="" class="wallpaper-calculator-for-woocommerce-form" name="wallpaper-calculator-for-woocommerce">
        <input type="hidden" name="wallpaper-calculator-for-woocommerce" value="1"/>
        <?php
        include_once WALLPAPER_CALCULATOR_WOO_DIR . 'includes/admin/tabs/options.php';
        include_once WALLPAPER_CALCULATOR_WOO_DIR . 'includes/admin/tabs/design.php';
        ?>
    </form>
</div>