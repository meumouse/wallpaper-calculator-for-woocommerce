<?php

/**
 * Plugin Name: 			Calculadora de Papel de Parede para WooCommerce
 * Description: 			Extensão que permite informar ao usuário quantas unidades de um produto ele deve comprar para lojas WooCommerce.
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.0.0
 * WC requires at least: 	6.0.0
 * WC tested up to: 		8.0.2
 * Requires PHP: 			7.2
 * Tested up to:      		6.3.1
 * Text Domain: 			wallpaper-calculator-for-woocommerce
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define WALLPAPER_CALCULATOR_WOO_PLUGIN_FILE.
if ( ! defined( 'WALLPAPER_CALCULATOR_WOO_PLUGIN_FILE' ) ) {
	define( 'WALLPAPER_CALCULATOR_WOO_PLUGIN_FILE', __FILE__ );
}

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

if ( ! class_exists( 'Wallpaper_Calculator_Woo' ) ) {
  
/**
 * Main Wallpaper_Calculator_Woo Class
 *
 * @class Wallpaper_Calculator_Woo
 * @version 1.0.0
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Wallpaper_Calculator_Woo {

		/**
		 * Wallpaper_Calculator_Woo The single instance of Wallpaper_Calculator_Woo.
		 *
		 * @var object
		 * @since 1.0.0
		 */
		private static $instance = null;

		/**
		 * The token
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $token;

		/**
		 * The version number
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $version;

		/**
		 * Constructor function.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->token = 'wallpaper-calculator-for-woocommerce';
			$this->version = '1.0.0';
			
			add_action( 'plugins_loaded', array( $this, 'wallpaper_calculator_woo_load_checker' ), 5 );
		}
		
		public function wallpaper_calculator_woo_load_checker() {
			if ( !function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}

			// Display notice if PHP version is bottom 7.2
			if ( version_compare( phpversion(), '7.2', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'wallpaper_calculator_woo_php_version_notice' ) );
				return;
			}
		
			// check if WooCommerce is active
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
				add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
				add_action( 'plugins_loaded', array( $this, 'setup_constants' ), 15 );
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 20 );
				add_action( 'plugins_loaded', array( $this, 'update_checker' ) );
				add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'wallpaper_calculator_woo_plugin_links' ), 10, 4 );

			} else {
				deactivate_plugins( 'wallpaper-calculator-for-woocommerce/wallpaper-calculator-for-woocommerce.php' );
				add_action( 'admin_notices', array( $this, 'wallpaper_calculator_woo_wc_deactivate_notice' ) );
			}

			// display notice if WooCommerce version is bottom 6.0
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) && version_compare( WC_VERSION, '6.0', '<' ) ) {
				add_action( 'admin_notices', array( $this, 'wallpaper_calculator_woo_wc_version_notice' ) );
				return;
			}
		}

		/**
		 * Main Wallpaper_Calculator_Woo Instance
		 *
		 * Ensures only one instance of Wallpaper_Calculator_Woo is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see Wallpaper_Calculator_Woo()
		 * @return Main Wallpaper_Calculator_Woo instance
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {
			// Plugin Folder Path
			if ( ! defined( 'WALLPAPER_CALCULATOR_WOO_DIR' ) ) {
				define( 'WALLPAPER_CALCULATOR_WOO_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL.
			if ( ! defined( 'WALLPAPER_CALCULATOR_WOO_URL' ) ) {
				define( 'WALLPAPER_CALCULATOR_WOO_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File.
			if ( ! defined( 'WALLPAPER_CALCULATOR_WOO_FILE' ) ) {
				define( 'WALLPAPER_CALCULATOR_WOO_FILE', __FILE__ );
			}

			$this->define( 'WALLPAPER_CALCULATOR_WOO_ABSPATH', dirname( WALLPAPER_CALCULATOR_WOO_FILE ) . '/' );
			$this->define( 'WALLPAPER_CALCULATOR_WOO_VERSION', $this->version );
		}

		/**
		 * Define constant if not already set.
		 *
		 * @param string      $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or wciend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
			}
		}

		/**
		 * Include required files
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_includes() {

			/**
			 * Class init plugin
			 * 
			 * @since 1.0.0
			 */
			include_once WALLPAPER_CALCULATOR_WOO_DIR . 'includes/class-wallpaper-calculator-for-woocommerce-autoloader.php';

			/**
			 * Admin options
			 * 
			 * @since 1.0.0
			 */
			include_once WALLPAPER_CALCULATOR_WOO_DIR . 'includes/admin/class-wallpaper-calculator-for-woocommerce-admin-options.php';

			/**
			 * Front-end options
			 * 
			 * @since 1.0.0
			 */
			include_once WALLPAPER_CALCULATOR_WOO_DIR . 'includes/classes/class-wallpaper-calculator-for-woocommerce-frontend-template.php';

			/**
			 * Custom design
			 * 
			 * @since 1.0.0
			 */
			include_once WALLPAPER_CALCULATOR_WOO_DIR . 'includes/classes/class-wallpaper-calculator-for-woocommerce-custom-design.php';
		}

		/**
		 * WooCommerce version notice
		 */
		public function wallpaper_calculator_woo_wc_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Calculadora de Papel de Parede para WooCommerce</strong> requer a versão do WooCommerce 6.0 ou maior. Faça a atualização do plugin WooCommerce.', 'wallpaper-calculator-for-woocommerce' ) . '</p>
				</div>';
		}

		/**
		 * Notice if WooCommerce is deactivate
		 */
		public function wallpaper_calculator_woo_wc_deactivate_notice() {
			if ( !current_user_can( 'install_plugins' ) ) { return; }

			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Calculadora de Papel de Parede para WooCommerce</strong> requer que <strong>WooCommerce</strong> esteja instalado e ativado.', 'wallpaper-calculator-for-woocommerce' ) . '</p>
				</div>';
		}

		/**
		 * PHP version notice
		 */
		public function wallpaper_calculator_woo_php_version_notice() {
			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Calculadora de Papel de Parede para WooCommerce</strong> requer a versão do PHP 7.2 ou maior. Contate o suporte da sua hospedagem para realizar a atualização.', 'wallpaper-calculator-for-woocommerce' ) . '</p>
				</div>';
		}


		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public function wallpaper_calculator_woo_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=wallpaper-calculator-for-woocommerce' ) . '">'. __( 'Configurar', 'wallpaper-calculator-for-woocommerce' ) .'</a>'
			);

			return array_merge( $plugins_links, $action_links );
		}

		/**
		 * Load the plugin text domain for translation.
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'wallpaper-calculator-for-woocommerce', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * Get the plugin url.
		 *
		 * @return string
		 */
		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', WALLPAPER_CALCULATOR_WOO_PLUGIN_FILE ) );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'wallpaper-calculator-for-woocommerce' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'wallpaper-calculator-for-woocommerce' ), '1.0.0' );
		}


		/**
		 * Plugin update checker
		 * 
		 * @since 1.0.0
		 * @return void
		 */
		public function update_checker() {
			require_once plugin_dir_path( __FILE__ ) . 'includes/updater/plugin-update-checker.php';

			$myUpdateChecker = PucFactory::buildUpdateChecker( 'https://raw.githubusercontent.com/meumouse/flexify-template-lib-for-elementor/main/updater/update-checker.json', __FILE__, 'wallpaper-calculator-for-woocommerce' );
		//	$myUpdateChecker->setBranch('main');
		}
	}
}

/**
 * Returns the main instance of Wallpaper_Calculator_Woo to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object Wallpaper_Calculator_Woo
 */
function Wallpaper_Calculator_Woo() { //phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return Wallpaper_Calculator_Woo::instance();
}

/**
 * Initialise the plugin
 */
Wallpaper_Calculator_Woo();