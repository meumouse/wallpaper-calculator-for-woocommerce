(function ($) {
    "use strict";

	/**
	 * Activate tabs
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		// Reads the index stored in localStorage, if it exists
		let activeTabIndex = localStorage.getItem('activeTabIndex');
		
		// Sets the active tab based on the value stored in localStorage
		if (activeTabIndex !== null) {
			$('.wallpaper-calculator-for-woocommerce-wrapper a.nav-tab').eq(activeTabIndex).click();
		}
	});
	  
	$(document).on('click', '.wallpaper-calculator-for-woocommerce-wrapper a.nav-tab', function() {
		// Stores the index of the active tab in localStorage
		let tabIndex = $(this).index();
		localStorage.setItem('activeTabIndex', tabIndex);
		
		let attrHref = $(this).attr('href');
		
		$('.wallpaper-calculator-for-woocommerce-wrapper a.nav-tab').removeClass('nav-tab-active');
		$('.wallpaper-calculator-for-woocommerce-form .nav-content').removeClass('active');
		$(this).addClass('nav-tab-active');
		$('.wallpaper-calculator-for-woocommerce-form').find(attrHref).addClass('active');
		
		return false;
	});


	/**
	 * Save options in AJAX
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		let settingsForm = $('form[name="wallpaper-calculator-for-woocommerce"]');
		let originalValues = settingsForm.serialize();
		var notificationDelay;
	
		settingsForm.on('change', function() {
			if (settingsForm.serialize() != originalValues) {
				ajax_save_options(); // send option serialized on change
			}
		});
	
		function ajax_save_options() {
			$.ajax({
				url: wallpaper_calculator_woo_params.ajax_url,
				type: 'POST',
				data: {
					action: 'wallpaper_calculator_woo_ajax_save_options',
					form_data: settingsForm.serialize(),
				},
				success: function(response) {
					try {
						var responseData = JSON.parse(response); // Parse the JSON response

						if (responseData.status === 'success') {
							originalValues = settingsForm.serialize();
							$('.updated-option-success').addClass('active');
							
							if (notificationDelay) {
								clearTimeout(notificationDelay);
							}
				
							notificationDelay = setTimeout( function() {
								$('.updated-option-success').fadeOut('fast', function() {
									$(this).removeClass('active').css('display', '');
								});
							}, 3000);
						}
					} catch (error) {
						console.log(error);
					}
				}
			});
		}
	});


	/**
	 * Display shortcode message in panel
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('select[name="hook_display_single_product"]').change( function() {
			let selectedOption = $(this).children("option:selected").val();

			if (selectedOption == 'shortcode') {
				$('#display-shortcode-info').removeClass('d-none');
			} else {
				$('#display-shortcode-info').addClass('d-none');
			}
		});
	});


	/**
	 * Allow insert only numbers and dot
	 * 
	 * @since 1.0.0
	 */
	jQuery( function($) {
		$('.allow-number-and-dots').keydown(function(e) {
			let key = e.charCode || e.keyCode || 0;

			return (
				(key >= 96 && key <= 105) ||
				(key >= 48 && key <= 57) ||
				key == 190 || key == 8
			);
		});
	});
	

	/**
	 * Allow insert only numbers, dot and dash in design tab
	 * 
	 * @since 2.1.0
	 */
	jQuery( function($) {
		$('.design-parameters').keydown(function(e) {
			let key = e.charCode || e.keyCode || 0;

			return (
				(key >= 96 && key <= 105) || // numbers (numeric keyboard)
				(key >= 48 && key <= 57) || // numbers (top keyboard)
				key == 190 || // dot
				key == 189 || key == 109 || // dash
				key == 8 // backspace
			);
		});
	});

})(jQuery);