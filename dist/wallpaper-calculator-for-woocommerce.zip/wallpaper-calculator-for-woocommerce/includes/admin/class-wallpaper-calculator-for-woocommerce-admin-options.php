<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; }

class Wallpaper_Calculator_Woo_Admin_Options extends Wallpaper_Calculator_Woo_Autoloader {

  /**
   * Wallpaper_Calculator_Woo_Admin constructor.
   *
   * @since 1.0.0
   * @access public
   */
  public function __construct() {
    parent::__construct();

    add_action( 'admin_menu', array( $this, 'wallpaper_calculator_woo_admin_menu' ) );
    add_action( 'admin_enqueue_scripts', array( $this, 'wallpaper_calculator_woo_admin_scripts' ) );
    add_action( 'wp_ajax_wallpaper_calculator_woo_ajax_save_options', array( $this, 'wallpaper_calculator_woo_ajax_save_options_callback' ) );
    add_action( 'wp_ajax_nopriv_wallpaper_calculator_woo_ajax_save_options', array( $this, 'wallpaper_calculator_woo_ajax_save_options_callback' ) );

    if ( $this->getSetting( 'enable_calculator') == 'yes' ) {
      add_action( 'woocommerce_product_options_general_product_data', array( $this, 'default_size_for_wallpaper_product' ) );
      add_action( 'woocommerce_process_product_meta', array( $this, 'save_fields_default_size_for_wallpaper_product' ) );
      add_action( 'admin_head', array( $this, 'dynamic_visibility_wallpaper_calculator' ) );
    }
  }

  /**
   * Function for create submenu in WooCommerce
   * 
   * @since 1.0.0
   * @access public
   * @return array
   */
  public function wallpaper_calculator_woo_admin_menu() {
    add_submenu_page(
      'woocommerce', // parent page slug
      esc_html__( 'Calculadora de Papel de Parede para WooCommerce', 'wallpaper-calculator-for-woocommerce'), // page title
      esc_html__( 'Calculadora de Papel de Parede', 'wallpaper-calculator-for-woocommerce'), // submenu title
      'manage_woocommerce', // user capabilities
      'wallpaper-calculator-for-woocommerce', // page slug
      array( $this, 'wallpaper_calculator_woo_settings_page' ), // public function for print content page
    );
  }


  /**
   * Plugin general setting page and save options
   * 
   * @since 1.0.0
   * @access public
   */
  public function wallpaper_calculator_woo_settings_page() {
    include_once WALLPAPER_CALCULATOR_WOO_DIR . 'includes/admin/settings.php';
  }


  /**
   * Enqueue admin scripts in page settings only
   * 
   * @since 1.0.0
   * @access public
   * @return void
   */
  public function wallpaper_calculator_woo_admin_scripts() {
    $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
    $version = Wallpaper_Calculator_Woo()->version;

    if ( false !== strpos($url, 'admin.php?page=wallpaper-calculator-for-woocommerce' ) ) {
      wp_enqueue_script( 'wallpaper-calculator-for-woocommerce-admin-scripts', WALLPAPER_CALCULATOR_WOO_URL . 'assets/js/wallpaper-calculator-for-woocommerce-admin-scripts.js', array('jquery'), $version );
      wp_enqueue_style( 'wallpaper-calculator-for-woocommerce-admin-styles', WALLPAPER_CALCULATOR_WOO_URL . 'assets/css/wallpaper-calculator-for-woocommerce-admin-styles.css', array(), $version );
  
      wp_localize_script( 'wallpaper-calculator-for-woocommerce-admin-scripts', 'wallpaper_calculator_woo_params', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
      ));
    }
  }


  /**
   * Save options in AJAX
   * 
   * @since 1.0.0
   * @return void
   * @package MeuMouse.com
   */
  public function wallpaper_calculator_woo_ajax_save_options_callback() {
    if ( isset( $_POST['form_data'] ) ) {
      // Convert serialized data into an array
      parse_str( $_POST['form_data'], $form_data );

      $options = get_option( 'wallpaper-calculator-for-woocommerce-setting' );
      $options['enable_calculator'] = isset( $form_data['enable_calculator'] ) ? 'yes' : 'no';
      $options['pulse_add_to_cart_button'] = isset( $form_data['pulse_add_to_cart_button'] ) ? 'yes' : 'no';

      // Merge the form data with the default options
      $updated_options = wp_parse_args( $form_data, $options );

      // Save the updated options
      update_option( 'wallpaper-calculator-for-woocommerce-setting', $updated_options );

      $response = array(
        'status' => 'success',
        'options' => $updated_options,
      );

      echo wp_json_encode( $response ); // Send JSON response
    }

    wp_die();
  }

  
  /**
   * Add fields on WooCommerce edit product page
   * 
   * @since 1.0.0
   * @return void
   * @package MeuMouse.com
   */
  public function default_size_for_wallpaper_product() {
    global $post;

    echo '<div class="options_group wallpaper-calculator-admin-product">';

    woocommerce_wp_checkbox(
      array(
          'id' => 'enable_set_size_wallpaper_product',
          'label' => __( 'Definir tamanho do papel de parede', 'wallpaper-calculator-for-woocommerce' ),
          'value' => get_post_meta( $post->ID, 'enable_set_size_wallpaper_product', true ),
      )
    );

    woocommerce_wp_text_input(
        array(
            'id' => '_length_wallpaper_product',
            'label' => __( 'Comprimento', 'wallpaper-calculator-for-woocommerce' ),
            'desc_tip' => true,
            'description' => __( 'Insira o comprimento do papel de parede', 'wallpaper-calculator-for-woocommerce' ),
            'type' => 'number',
            'custom_attributes' => array(
                'step' => '0.01',
                'min' => '0',
            ),
            'value' => get_post_meta( $post->ID, '_length_wallpaper_product', true ) ?: $this->getSetting( 'default_lenght_wallpaper_product' ),
        )
    );

    woocommerce_wp_text_input(
        array(
            'id' => '_width_wallpaper_product',
            'label' => __( 'Largura', 'wallpaper-calculator-for-woocommerce' ),
            'desc_tip' => true,
            'description' => __( 'Insira a largura do papel de parede', 'wallpaper-calculator-for-woocommerce' ),
            'type' => 'number',
            'custom_attributes' => array(
                'step' => '0.01',
                'min' => '0',
            ),
            'value' => get_post_meta( $post->ID, '_width_wallpaper_product', true ) ?: $this->getSetting( 'default_width_wallpaper_product' ),
        )
    );

    woocommerce_wp_select(
        array(
            'id' => '_measure_unit_wallpaper_product',
            'label' => __( 'Unidade de medida', 'wallpaper-calculator-for-woocommerce' ),
            'options' => array(
                'meters' => __( 'Metros', 'wallpaper-calculator-for-woocommerce' ),
            ),
            'value' => get_post_meta( $post->ID, '_measure_unit_wallpaper_product', true ) ?: $this->getSetting( 'measure_unit' ),
            'desc_tip' => true,
            'description' => __( 'Unidade de medida do papel de parede', 'wallpaper-calculator-for-woocommerce' ),
        )
    );

    echo '</div>';
  }

  
  /**
   * Save options for admin fields
   * 
   * @since 1.0.0
   * @return
   * @package MeuMouse.com
   */
  public function save_fields_default_size_for_wallpaper_product( $post_id ) {
    $enable_set_size = isset( $_POST['enable_set_size_wallpaper_product'] ) ? 'yes' : 'no';
    $length = isset( $_POST['_length_wallpaper_product'] ) ? floatval( $_POST['_length_wallpaper_product'] ) : '';
    $width = isset( $_POST['_width_wallpaper_product'] ) ? floatval( $_POST['_width_wallpaper_product'] ) : '';
    $measure_unit = isset( $_POST['_measure_unit_wallpaper_product'] ) ? sanitize_text_field( $_POST['_measure_unit_wallpaper_product'] ) : '';

    update_post_meta( $post_id, 'enable_set_size_wallpaper_product', $enable_set_size );
    update_post_meta( $post_id, '_length_wallpaper_product', $length );
    update_post_meta( $post_id, '_width_wallpaper_product', $width );
    update_post_meta( $post_id, '_measure_unit_wallpaper_product', $measure_unit );
  }


  /**
   * Inject JavaScript on page product WooCommerce
   * 
   * @since 1.0.0
   */
  public function dynamic_visibility_wallpaper_calculator() {
    global $post;

    // checks if it's a product edit page
    if ( isset( $post->post_type) && $post->post_type === 'product' && is_admin() ) {
        ?>
        <script type="text/javascript">
            jQuery(document).ready( function($) {
              function toggleDiscountFields() {
                  let enableCalculator = $('#enable_set_size_wallpaper_product').is(':checked');

                  if (enableCalculator) {
                      $('p._length_wallpaper_product_field, p._width_wallpaper_product_field, p._measure_unit_wallpaper_product_field').show();
                  } else {
                      $('p._length_wallpaper_product_field, p._width_wallpaper_product_field, p._measure_unit_wallpaper_product_field').hide();
                  }
              }

              toggleDiscountFields();

              $('#enable_set_size_wallpaper_product').on('change', function() {
                  toggleDiscountFields();
              });
          });
        </script>
        <?php
    }
  }
}

new Wallpaper_Calculator_Woo_Admin_Options();