<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
} ?>

<div id="design-settings" class="nav-content ">
   <table class="form-table" >
      <tr>
         <th>
            <?php echo esc_html__( 'Cor principal dos elementos', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__( 'Selecione a cor principal dos elementos da calculadora.' ) ?></span>
         </th>
         <td>
            <input type="color" name="main_color_elements" class="form-control-color" value="<?php echo $this->getSetting( 'main_color_elements' ) ?>"/>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Cor do aviso de quantidade necessária', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__( 'Selecione a cor do aviso de quantidade necessária que é exibido após o cálculo.' ) ?></span>
         </th>
         <td>
            <input type="color" name="alert_color" class="form-control-color" value="<?php echo $this->getSetting( 'alert_color' ) ?>"/>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Margem superior da calculadora', 'wallpaper-calculator-for-woocommerce' ) ?>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="margin_top_wallpaper_calculator" class="form-control input-control-wd-5 design-parameters" value="<?php echo $this->getSetting( 'margin_top_wallpaper_calculator' ) ?>"/>
               <select id="unit_margin_top_wallpaper_calculator" class="form-select" name="unit_margin_top_wallpaper_calculator">
                  <option value="px" <?php echo ( $this->getSetting( 'unit_margin_top_wallpaper_calculator' ) == 'px' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'px', 'wallpaper-calculator-for-woocommerce' ) ?></option>
                  <option value="em" <?php echo ( $this->getSetting( 'unit_margin_top_wallpaper_calculator' ) == 'em' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'em', 'wallpaper-calculator-for-woocommerce' ) ?></option>
                  <option value="rem" <?php echo ( $this->getSetting( 'unit_margin_top_wallpaper_calculator' ) == 'rem' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'rem', 'wallpaper-calculator-for-woocommerce' ) ?></option>
               </select>
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Margem inferior da calculadora', 'wallpaper-calculator-for-woocommerce' ) ?>
         </th>
         <td>
            <div class="input-group">
               <input type="text" name="margin_bottom_wallpaper_calculator" class="form-control input-control-wd-5 design-parameters" value="<?php echo $this->getSetting( 'margin_bottom_wallpaper_calculator' ) ?>"/>
               <select id="unit_margin_bottom_wallpaper_calculator" class="form-select" name="unit_margin_bottom_wallpaper_calculator">
                  <option value="px" <?php echo ( $this->getSetting( 'unit_margin_bottom_wallpaper_calculator' ) == 'px' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'px', 'wallpaper-calculator-for-woocommerce' ) ?></option>
                  <option value="em" <?php echo ( $this->getSetting( 'unit_margin_bottom_wallpaper_calculator' ) == 'em' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'em', 'wallpaper-calculator-for-woocommerce' ) ?></option>
                  <option value="rem" <?php echo ( $this->getSetting( 'unit_margin_bottom_wallpaper_calculator' ) == 'rem' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'rem', 'wallpaper-calculator-for-woocommerce' ) ?></option>
               </select>
            </div>
         </td>
      </tr>
   </table>
</div>