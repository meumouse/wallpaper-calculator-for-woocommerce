<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit; } ?>


<div id="general-settings" class="nav-content active">
   <table class="form-table">
      <tr>
         <th>
            <?php echo esc_html__( 'Ativar calculadora', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__('Se ativo, irá exibir a calculadora de papel de parede em todos os produtos.', 'wallpaper-calculator-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="enable_calculator" name="enable_calculator" value="yes" <?php checked( $this->getSetting( 'enable_calculator') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Pulsar botão de adicionar ao carrinho', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__('Se ativo, irá adicionar o efeito de pulsar ao botão de adicionar ao carrinho, estimulando o usuário a iniciar a finalização de compra. (Recomendado)', 'wallpaper-calculator-for-woocommerce' ) ?></span>
         </th>
         <td>
            <div class="form-check form-switch">
               <input type="checkbox" class="toggle-switch" id="pulse_add_to_cart_button" name="pulse_add_to_cart_button" value="yes" <?php checked( $this->getSetting( 'pulse_add_to_cart_button') == 'yes' ); ?> />
            </div>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Comprimento padrão do papel de parede', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__( 'Informe um comprimento padrão que será exibida na edição dos produtos. Ou deixe em branco para não utilizar', 'wallpaper-calculator-for-woocommerce' ) ?></span>
         </th>
         <td>
            <input type="text" name="default_lenght_wallpaper_product" class="form-control input-control-wd-5 allow-number-and-dots" value="<?php echo $this->getSetting( 'default_lenght_wallpaper_product' ) ?>"/>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Largura padrão do papel de parede', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__( 'Informe uma largura padrão que será exibida na edição dos produtos. Ou deixe em branco para não utilizar', 'wallpaper-calculator-for-woocommerce' ) ?></span>
         </th>
         <td>
            <input type="text" name="default_width_wallpaper_product" class="form-control input-control-wd-5 allow-number-and-dots" value="<?php echo $this->getSetting( 'default_width_wallpaper_product' ) ?>"/>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Unidade de medida padrão', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__( 'Selecione qual unidade de medida padrão que será exibida na edição dos produtos.', 'wallpaper-calculator-for-woocommerce' ) ?></span>
         </th>
         <td>
            <select name="measure_unit" class="form-select">
               <option value="meters" <?php echo ( $this->getSetting( 'measure_unit' ) == 'meters' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Metros (Padrão)', 'wallpaper-calculator-for-woocommerce' ) ?></option>
            </select>
         </td>
      </tr>
      <tr>
         <th>
            <?php echo esc_html__( 'Posição de exibição da calculadora', 'wallpaper-calculator-for-woocommerce' ) ?>
            <span class="wallpaper-calculator-for-woocommerce-description"><?php echo esc_html__( 'Selecione a posição que será exibido a calculadora na página do produto individual.', 'wallpaper-calculator-for-woocommerce' ) ?></span>
            <span id="display-shortcode-info" class="wallpaper-calculator-for-woocommerce-description <?php echo ( $this->getSetting( 'hook_display_single_product' ) != 'shortcode' ) ? "d-none" : ""; ?>"><?php echo esc_html__( 'Shortcode: ', 'wallpaper-calculator-for-woocommerce' ) ?><code>[wallpaper_calculator_single_product]</code></span>
         </th>
         <td>
            <select name="hook_display_single_product" class="form-select">
               <option value="before_cart" <?php echo ( $this->getSetting( 'hook_display_single_product' ) == 'before_cart' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Antes do carrinho (Padrão)', 'wallpaper-calculator-for-woocommerce' ) ?></option>
               <option value="after_cart" <?php echo ( $this->getSetting( 'hook_display_single_product' ) == 'after_cart' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Depois do carrinho', 'wallpaper-calculator-for-woocommerce' ) ?></option>
               <option value="shortcode" <?php echo ( $this->getSetting( 'hook_display_single_product' ) == 'shortcode' ) ? "selected=selected" : ""; ?>><?php echo esc_html__( 'Shortcode', 'wallpaper-calculator-for-woocommerce' ) ?></option>
            </select>
         </td>
      </tr>
   </table>
</div>