<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main class
 * 
 * @package MeuMouse.com
 * @version 1.0.0
 */
class Wallpaper_Calculator_Woo_Autoloader {

	public $wallpaper_calculator_woo_settings = array();
  
  public function __construct() {
    // load plugin setting
    if( empty( $this->wallpaper_calculator_woo_settings ) ) {
      $this->wallpaper_calculator_woo_settings = get_option( 'wallpaper-calculator-for-woocommerce-setting' );
    }
  }


  /**
	 * Plugin default settings
   * 
	 * @return array
	 * @since 1.0.0
	 * @access public
	 */
	public $default_settings = array(
    'enable_calculator' => 'yes',
    'pulse_add_to_cart_button' => 'yes',
    'default_lenght_wallpaper_product' => '3.0',
    'default_width_wallpaper_product' => '0.58',
    'measure_unit' => 'meters',
    'hook_display_single_product' => 'before_cart',
    'main_color_elements' => '#008aff',
    'alert_color' => '#4475de',
    'margin_top_wallpaper_calculator' => '2',
    'unit_margin_top_wallpaper_calculator' => 'rem',
    'margin_bottom_wallpaper_calculator' => '2',
    'unit_margin_bottom_wallpaper_calculator' => 'rem',
  );


  /**
	 * Function for get plugin general settings
	 * 
	 * @return string 
	 * @since 1.0.0
	 * @access public
	 */
	public function getSetting( $key ) {
    if( ! empty( $this->wallpaper_calculator_woo_settings) && isset( $this->wallpaper_calculator_woo_settings[ $key ] ) ) {
      return $this->wallpaper_calculator_woo_settings[ $key ];
    }

    if( isset( $this->default_settings[ $key ] ) ) {
      return $this->default_settings[ $key ];
    }

    return false;
  }
}

new Wallpaper_Calculator_Woo_Autoloader();