<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Change colors on front-end
 *
 * @package MeuMouse.com
 * @since 1.0.0
 */

class Wallpaper_Calculator_Woo_Custom_Design extends Wallpaper_Calculator_Woo_Autoloader {

  public function __construct() {
    parent::__construct();

    add_action( 'wp_head', array( $this, 'wallpaper_calculator_woo_custom_design' ) );
  }


  /**
   * Custom option design
   * 
   * @since 1.0.0
   * @return string
   * @package MeuMouse.com
   */
  public function wallpaper_calculator_woo_custom_design() {
    $primary_color = $this->getSetting( 'main_color_elements' );
    $primary_color_70_opacity = $this->generate_rgba_color( $primary_color, 70 );
    $primary_color_0_opacity = $this->generate_rgba_color( $primary_color, 0 );
    $alert_color_primary = $this->getSetting( 'alert_color' );
    $alert_color_primary_20_opacity = $this->generate_rgba_color( $alert_color_primary, 9 );

    $css = '.form-select:focus, input.form-control:focus {';
      $css .= 'border-color:'. $primary_color .' !important;';
    $css .= '}';

    $css .= '#wallpaper-calculator {';
      $css .= 'margin-top:'. $this->getSetting( 'margin_top_wallpaper_calculator' ) . $this->getSetting( 'unit_margin_top_wallpaper_calculator' ) .' !important;';
      $css .= 'margin-bottom:'. $this->getSetting( 'margin_bottom_wallpaper_calculator' ) . $this->getSetting( 'unit_margin_bottom_wallpaper_calculator' ) .' !important;';
    $css .= '}';

    $css .= '.wallpaper-calculator-result {';
      $css .= 'color:'. $alert_color_primary .' !important;';
      $css .= 'background-color:'. $alert_color_primary_20_opacity .' !important;';
    $css .= '}';

    // pulse add to cart button color
    if ( $this->getSetting( 'pulse_add_to_cart_button') == 'yes' ) {
      $css .= '.pulse-add-to-cart-button {';
        $css .= 'position: relative;';
      $css .= '}';

      $css .= '.pulse-add-to-cart-button::before {';
        $css .= 'content: "";';
        $css .= 'position: absolute;';
        $css .= 'top: -2px;';
        $css .= 'left: -2px;';
        $css .= 'right: -2px;';
        $css .= 'bottom: -2px;';
        $css .= 'border-radius: 5px;';
        $css .= 'animation: pulse 2s infinite;';
      $css .= '}';

      $css .= '.pulse-add-to-cart-button:hover::before {';
        $css .= 'animation: none;';
      $css .= '}';

      $css .= '@keyframes pulse {';
        $css .= '0% {';
          $css .= 'transform: scale(0.95);';
          $css .= 'box-shadow: 0 0 0 0 '. $primary_color_70_opacity .';';
        $css .= '}';
        $css .= '70% {';
          $css .= 'transform: scale(1);';
          $css .= 'box-shadow: 0 0 0 10px '. $primary_color_0_opacity .';';
        $css .= '}';
        $css .= '100% {';
          $css .= 'transform: scale(0.95);';
          $css .= 'box-shadow: 0 0 0 0 '. $primary_color_0_opacity .';';
        $css .= '}';
      $css .= '}';
    }

    ?>
    <style type="text/css">
      <?php echo $css; ?>
    </style> <?php
  }


  /**
   * Generate RGBA color from primary color
   * 
   * @since 1.0.0
   * @return string
   * @package MeuMouse.com
   */
  public function generate_rgba_color($color, $opacity) {
    // removes the "#" character if present 
    $color = str_replace("#", "", $color);

    // gets the RGB decimal value of each color component
    $red = hexdec(substr($color, 0, 2));
    $green = hexdec(substr($color, 2, 2));
    $blue = hexdec(substr($color, 4, 2));
    $opacity = $opacity / 100;

    // generates RGBA color based on foreground color and opacity
    $rgba_color = "rgba($red, $green, $blue, $opacity)";

    return $rgba_color;
  }

}

new Wallpaper_Calculator_Woo_Custom_Design();